module.exports=[66922,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_prayer-rock_page_actions_0b90e70e.js.map