module.exports=[2948,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_prayer-rock-story_page_actions_cb26f29d.js.map