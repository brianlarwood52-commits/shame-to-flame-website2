module.exports=[27896,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_healing-pathways_page_actions_a1507404.js.map