module.exports=[51272,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_daily-fire_page_actions_c45451d4.js.map