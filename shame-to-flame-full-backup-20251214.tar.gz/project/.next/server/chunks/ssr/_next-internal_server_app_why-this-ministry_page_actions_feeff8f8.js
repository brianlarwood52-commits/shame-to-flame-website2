module.exports=[47504,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_why-this-ministry_page_actions_feeff8f8.js.map