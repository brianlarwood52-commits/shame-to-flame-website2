module.exports=[10524,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_sda-commentary-search_page_actions_58615467.js.map