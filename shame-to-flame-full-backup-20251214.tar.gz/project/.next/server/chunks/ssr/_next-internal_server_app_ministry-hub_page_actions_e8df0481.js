module.exports=[97515,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_ministry-hub_page_actions_e8df0481.js.map