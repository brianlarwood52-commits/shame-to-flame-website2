1:"$Sreact.fragment"
2:I[88589,["/_next/static/chunks/cc04975f63a0014c.js"],"default"]
3:I[22016,["/_next/static/chunks/cc04975f63a0014c.js"],""]
a:I[13642,["/_next/static/chunks/cc04975f63a0014c.js"],"default"]
b:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/247eb132b7f7b574.js"],"OutletBoundary"]
c:"$Sreact.suspense"
0:{"buildId":"TUS1Ho1RANlNZbdz903Ku","rsc":["$","$1","c",{"children":[[["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@type\":\"BlogPosting\",\"headline\":\"When Family Becomes the Wound\",\"description\":\"Family is supposed to be our safe place, but what happens when the people who should love us most become the source of our deepest pain?\",\"author\":{\"@type\":\"Person\",\"name\":\"Brian\"},\"datePublished\":\"2024-01-10\",\"publisher\":{\"@type\":\"Organization\",\"name\":\"Shame to Flame Ministry\",\"url\":\"https://shametoflame.faith\"},\"mainEntityOfPage\":{\"@type\":\"WebPage\",\"@id\":\"https://shametoflame.faith/prayer-rock/blog/when-family-becomes-the-wound\"},\"keywords\":\"family dysfunction, narcissism, boundaries, healing\"}"}}],["$","div",null,{"className":"min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50","children":[["$","$L2",null,{}],["$","article",null,{"className":"py-12 px-4 sm:px-6 lg:px-8","children":["$","div",null,{"className":"max-w-4xl mx-auto","children":[["$","$L3",null,{"href":"/prayer-rock","className":"inline-flex items-center text-orange-600 hover:text-orange-700 mb-8 group","children":[["$","svg",null,{"xmlns":"http://www.w3.org/2000/svg","width":24,"height":24,"viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":2,"strokeLinecap":"round","strokeLinejoin":"round","className":"lucide lucide-arrow-left w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform","children":[["$","path","1l729n",{"d":"m12 19-7-7 7-7"}],["$","path","x3x0zl",{"d":"M19 12H5"}],"$undefined"]}],"Back to Prayer Rock Archive"]}],["$","div",null,{"className":"mb-8","children":[["$","span",null,{"className":"inline-block px-3 py-1 rounded-full text-xs font-medium mb-4 bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300","children":"Reflection"}],["$","h1",null,{"className":"text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4 font-serif","children":"When Family Becomes the Wound"}],["$","div",null,{"className":"flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400 mb-6","children":[["$","div",null,{"className":"flex items-center","children":[["$","svg",null,{"xmlns":"http://www.w3.org/2000/svg","width":24,"height":24,"viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":2,"strokeLinecap":"round","strokeLinejoin":"round","className":"lucide lucide-user w-4 h-4 mr-2","children":[["$","path","975kel",{"d":"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"}],["$","circle","17ys0d",{"cx":"12","cy":"7","r":"4"}],"$undefined"]}],["$","span",null,{"children":"Brian"}]]}],["$","div",null,{"className":"flex items-center","children":[["$","svg",null,{"xmlns":"http://www.w3.org/2000/svg","width":24,"height":24,"viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":2,"strokeLinecap":"round","strokeLinejoin":"round","className":"lucide lucide-calendar w-4 h-4 mr-2","children":[["$","path","1cmpym",{"d":"M8 2v4"}],["$","path","4m81vk",{"d":"M16 2v4"}],["$","rect","1hopcy",{"width":"18","height":"18","x":"3","y":"4","rx":"2"}],["$","path","8toen8",{"d":"M3 10h18"}],"$undefined"]}],["$","span",null,{"children":"January 10, 2024"}]]}],["$","div",null,{"className":"flex items-center","children":[["$","svg",null,{"xmlns":"http://www.w3.org/2000/svg","width":24,"height":24,"viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":2,"strokeLinecap":"round","strokeLinejoin":"round","className":"lucide lucide-clock w-4 h-4 mr-2","children":[["$","circle","1mglay",{"cx":"12","cy":"12","r":"10"}],["$","polyline","68esgv",{"points":"12 6 12 12 16 14"}],"$undefined"]}],["$","span",null,{"children":[8," min read"]}]]}]]}],["$","p",null,{"className":"text-xl text-gray-600 dark:text-gray-300 leading-relaxed","children":"Family is supposed to be our safe place, but what happens when the people who should love us most become the source of our deepest pain?"}]]}],["$","div",null,{"className":"prose prose-lg max-w-none dark:prose-invert prose-headings:font-serif prose-headings:text-gray-900 dark:prose-headings:text-white prose-p:text-gray-700 dark:prose-p:text-gray-300 prose-a:text-orange-600 dark:prose-a:text-orange-400 prose-strong:text-gray-900 dark:prose-strong:text-white prose-ul:text-gray-700 dark:prose-ul:text-gray-300 prose-ol:text-gray-700 dark:prose-ol:text-gray-300","children":"$L4"}],"$L5","$L6"]}]}],"$L7"]}]],null,"$L8"]}],"loading":null,"isPartial":false}
9:T15cc,
<p>Family is supposed to be our safe place, but what happens when the people who should love us most become the source of our deepest pain?</p>

<h2>The Myth of Perfect Families</h2>

<p>We grow up with this idea that family equals safety, that blood is thicker than water, that family will always be there for us. But for many of us, family has been the source of our deepest wounds—the place where we first learned shame, where we discovered that love could be conditional, where we realized that the people closest to us could hurt us the most.</p>

<h2>The Narcissist in the Family</h2>

<p>Dealing with a narcissistic family member is like trying to have a relationship with someone who can only see their own reflection. Everything becomes about them—your pain, your joy, your needs, your boundaries. They don't see you as a separate person with your own feelings and experiences; you exist only as an extension of their ego.</p>

<p>In my recent family reunion experience, I watched as one cousin's narcissistic behavior poisoned what should have been a healing gathering. She couldn't tolerate not being the center of attention. She couldn't respect boundaries. She couldn't see how her actions affected others—or if she could see it, she simply didn't care.</p>

<h2>The Ripple Effect of Family Dysfunction</h2>

<p>What hurt the most wasn't just her behavior toward me—it was watching her disrespect my mother and realizing that standing up for what was right meant losing connection with other family members who chose to enable rather than confront the dysfunction.</p>

<p>This is the cruel reality of family dysfunction: often, the healthy people end up isolated while the unhealthy behavior gets protected. The truth-tellers become the troublemakers. The boundary-setters become the "difficult" ones.</p>

<h2>The Shame of Family Wounds</h2>

<p>There's a special kind of shame that comes with family wounds. Society tells us we should love our family unconditionally, that we should forgive and forget, that family is everything. So when family hurts us, we often blame ourselves:</p>

<ul>
<li>"Maybe I'm too sensitive"</li>
<li>"Maybe I should just keep the peace"</li>
<li>"Maybe I'm the problem"</li>
<li>"Maybe I don't deserve better"</li>
</ul>

<p>But here's the truth: you are not responsible for other people's dysfunction, even if they're family. You are not required to set yourself on fire to keep others warm. You are not obligated to accept abuse in the name of family loyalty.</p>

<h2>Setting Boundaries with Family</h2>

<p>One of the hardest lessons I've learned is that sometimes loving someone means limiting your exposure to them. Sometimes the most loving thing you can do—for yourself and for them—is to create boundaries that protect your peace and their opportunity to face the consequences of their choices.</p>

<p>This doesn't mean we stop loving them. It doesn't mean we wish them harm. It means we love ourselves enough to refuse to participate in dysfunction. It means we love them enough to stop enabling their harmful behavior.</p>

<h2>Finding Your True Family</h2>

<p>Here's what I've discovered: family isn't just about blood. Family is about people who see you, value you, support your growth, and love you well. Sometimes our biological family fills this role beautifully. Sometimes we have to create our own family from friends, mentors, and chosen relationships.</p>

<p>God has a way of bringing people into our lives who become the family we needed all along. These are the people who celebrate our victories, comfort us in our pain, and love us not despite our flaws but including them.</p>

<h2>The Healing Journey</h2>

<p>Healing from family wounds is a unique kind of journey. It involves:</p>

<ul>
<li><strong>Grieving the family you needed but didn't have</strong></li>
<li><strong>Accepting the family you have without excusing their dysfunction</strong></li>
<li><strong>Creating boundaries that protect your peace</strong></li>
<li><strong>Finding healthy relationships that model what love should look like</strong></li>
<li><strong>Learning to parent yourself in the ways you weren't parented well</strong></li>
</ul>

<h2>God's Heart for the Wounded</h2>

<p>The beautiful thing about God is that He understands family dysfunction intimately. His own earthly family didn't always understand Him. His disciples—His chosen family—betrayed and abandoned Him. He knows what it's like to be misunderstood, rejected, and hurt by the people closest to Him.</p>

<p>But God also shows us what true family looks like. In His kingdom, we are all adopted children, all equally loved, all given the same inheritance. There's no favoritism, no conditional love, no manipulation or control. Just pure, unconditional, transformative love.</p>

<h2>Your Story Matters</h2>

<p>If you're reading this and recognizing your own family story, I want you to know: your pain is valid. Your boundaries are necessary. Your healing is possible. You are not too much, too sensitive, or too difficult. You are a beloved child of God who deserves to be loved well.</p>

<p>Your family wounds don't disqualify you from love—they qualify you to recognize real love when it comes. They don't make you broken beyond repair—they make you a wounded healer who can help others find their way to wholeness.</p>

<p><em>What family wounds are you carrying? How is God inviting you to find healing and create healthy boundaries? Remember: you can love someone and still protect yourself from their dysfunction.</em></p>
    4:["$","div",null,{"dangerouslySetInnerHTML":{"__html":"$9"}}]
5:["$","div",null,{"className":"mt-8 pt-6 border-t border-gray-200 dark:border-gray-700","children":["$","div",null,{"className":"flex flex-wrap gap-2","children":[["$","span",null,{"className":"text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center","children":[["$","svg",null,{"xmlns":"http://www.w3.org/2000/svg","width":24,"height":24,"viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":2,"strokeLinecap":"round","strokeLinejoin":"round","className":"lucide lucide-tag w-4 h-4 mr-2","children":[["$","path","vktsd0",{"d":"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"}],["$","circle","kqv944",{"cx":"7.5","cy":"7.5","r":".5","fill":"currentColor"}],"$undefined"]}],"Tags:"]}],[["$","span","0",{"className":"px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-sm","children":["#","family dysfunction"]}],["$","span","1",{"className":"px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-sm","children":["#","narcissism"]}],["$","span","2",{"className":"px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-sm","children":["#","boundaries"]}],["$","span","3",{"className":"px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-sm","children":["#","healing"]}]]]}]}]
6:["$","div",null,{"className":"mt-12 bg-gradient-to-r from-orange-50 to-red-50 dark:from-gray-800 dark:to-gray-700 rounded-xl p-8","children":[["$","h3",null,{"className":"text-2xl font-bold text-gray-900 dark:text-white mb-4 font-serif","children":"Share Your Story"}],["$","p",null,{"className":"text-gray-700 dark:text-gray-300 mb-6","children":"Has this reflection resonated with you? We'd love to hear how God is working in your life."}],["$","$L3",null,{"href":"/submit-prayer","className":"inline-block bg-gradient-to-r from-orange-500 to-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-orange-600 hover:to-red-700 transition-all duration-200 shadow-lg hover:shadow-xl","children":"Share Your Prayer Request"}]]}]
7:["$","$La",null,{}]
8:["$","$Lb",null,{"children":["$","$c",null,{"name":"Next.MetadataOutlet","children":"$@d"}]}]
d:null
